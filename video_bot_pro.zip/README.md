# 🤖 Professional Video Downloader Bot

YouTube, TikTok, Instagram videolarini yuklab beruvchi professional Telegram bot.

## 📦 Fayllar
```
bot.py          — Asosiy fayl (barcha handlerlar)
database.py     — SQLite bilan ma'lumotlar bazasi
downloader.py   — yt-dlp bilan video yuklab olish
i18n.py         — 3 til: O'zbek, Rus, Ingliz
keyboards.py    — Barcha tugmalar (Reply + Inline)
requirements.txt
Procfile        — Railway uchun
```

## ⚡ Imkoniyatlar
- ✅ YouTube, TikTok, Instagram
- 🌐 3 til (O'zbek / Rus / Ingliz)
- 📊 7 ta sifat: 144p, 360p, 480p, 720p, 1080p, Best, MP3
- 💾 SQLite baza (foydalanuvchilar, yuklanmalar, statistika)
- 📊 Har bir foydalanuvchi o'z statistikasini ko'radi
- 🔐 Admin panel: statistika, foydalanuvchilar, ban, broadcast
- 🚫 Ban tizimi
- 📢 Broadcast — barcha foydalanuvchilarga xabar yuborish
- ⌨️ Reply + Inline klaviatura (ikkalasi ham)

## 🚀 Railway.app ga deploy

### 1. GitHub repo tayyorlash
Barcha fayllarni yangi GitHub repoga yuklang.

### 2. Railway da yangi project
1. railway.app → "New Project"
2. "Deploy from GitHub repo" → reponi tanlang

### 3. Environment Variables
Railway da "Variables" bo'limiga qo'shing:

| Key | Value |
|-----|-------|
| `BOT_TOKEN` | BotFather dan olgan token |
| `ADMIN_IDS` | Sizning Telegram ID ingiz (masalan: `123456789`) |

> Telegram ID ni bilish: @userinfobot ga /start yuboring

Bir nechta admin bo'lsa vergul bilan: `123456,789012`

### 4. Deploy
"Deploy" tugmasini bosing — bot 24/7 ishga tushadi!

## 💻 Lokal ishlatish (test uchun)

```bash
pip install -r requirements.txt

export BOT_TOKEN="your_token_here"
export ADMIN_IDS="your_telegram_id"

python bot.py
```

## 📱 Bot buyruqlari

| Buyruq | Tavsif |
|--------|--------|
| /start | Bosh menyu |
| /help | Yordam |
| /settings | Sozlamalar |
| /mystats | Shaxsiy statistika |
| /admin | Admin panel (faqat adminlar) |
| /cancel | Joriy amalni bekor qilish |

## 🔐 Admin panel

`/admin` buyrug'ini yuboring va quyidagilarni ko'rasiz:

- **📊 Umumiy statistika** — jami foydalanuvchilar, yuklanmalar, platformalar, hajm
- **👥 Foydalanuvchilar** — ro'yxat, yuklanmalar soni, ban/unban
- **📢 Broadcast** — barcha foydalanuvchilarga xabar yuborish
